# Blockvile Updater (its own app, its own website)

A small separate app that updates Blockvile Plus OS on every device signed in to your account — and lets people go back to an older version or forward to a newer one.

## How it is linked to the OS
Through **Supabase** (the same project and the same sign-in the OS already uses):

| Table | What it holds |
|---|---|
| `os_releases` | the versions you publish (you add them with `supabase/releases.sql`) |
| `os_status` | each device tells Supabase which version it runs (the OS does this by itself when signed in) |
| `os_requests` | the Updater asks one device to switch; the device shows a card and only changes when its owner taps **Switch** |

## Set it up (about 5 minutes)
1. **SQL:** Supabase → SQL Editor → paste `supabase/updater-link.sql` → Run. Then paste `supabase/releases.sql` → Run (re-run it after every new release; `tools/make-version.py` rewrites it).
2. **Sign-in redirect:** Supabase → Authentication → URL Configuration → add this Updater's web address to *Redirect URLs* (needed for Google/Microsoft sign-in; email sign-in works without it).
3. **config.js:** paste your Supabase URL and anon key (same as the OS), and your Blockvile website address in `osUrl`.
4. **Publish it as its OWN repo:** create a new GitHub repository (e.g. `blockvile-updater`), upload everything in this folder to the top level, then Settings → Pages → Deploy from a branch → `main` / root.
5. Open `https://<you>.github.io/blockvile-updater/` and sign in. Install it to the home screen from the browser menu.

The Blockvile OS you publish must be the version that has the link (3.20 or newer). Devices appear in the Updater after they have opened Blockvile once while signed in.
