BLOCKVILE UPDATER
=================
The updater is a small separate app for updating Blockvile Plus OS (check for updates, switch version, or install an update from a zip/folder).

Install it: upload these files to the SAME place on your website as Blockvile's index.html
(for GitHub: add updater.html, updater.webmanifest and the icons folder to the repository's top level).
It must sit beside Blockvile so it can update it (browsers keep each website's data separate).

Then open  <your-site>/updater.html  and install it to your home screen (Chrome menu > Install app).
